import static org.junit.Assert.*;

import org.junit.Test;

public class Kilometro {

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

	@Test
	public void testToKilometro() {
		fail("Not yet implemented");
	}

	@Test
	public void testToMilla() {
		fail("Not yet implemented");
	}

	@Test
	public void testToPie() {
		fail("Not yet implemented");
	}

	@Test
	public void testToMetro() {
		fail("Not yet implemented");
	}

	@Test
	public void testKilometro() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddUnidadesDeLongitud() {
		fail("Not yet implemented");
	}

}
