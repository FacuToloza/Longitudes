import java.util.Random;

public class Ejercicio_07 {
	public int 	max  = 0, 
				min  = 0,
				prom = 0;
	
	public static void main(String[] args) {
		Ejercicio_07 ej = new Ejercicio_07();
		int cant = 10000 + new Random().nextInt(10001);

		ej.punto_1(cant);
		ej.punto_2(cant);
		ej.punto_3();
	}
		
	public void punto_1(int cant) {
		Archivo archivo_in = new Archivo("aleatorio.in");
		Random rand = new Random();
		int[] numeros_random = new int[cant];
		
		for (int i = 0; i < cant; i++) {
			numeros_random[i] = rand.nextInt(12001);
		}
		
		archivo_in.guardarArchivo(numeros_random);
	}
	
	public void punto_2(int cant) {
		Archivo archivo_in = new Archivo("aleatorio.in");
		int[] numeros = archivo_in.leerArchivo(); 
		int total = numeros[0];

		max = numeros[0];
		min = numeros[0];
				
		for (int i = 1; i < cant; i++) {
			
			total += numeros[i];
			
			if(numeros[i] < min) {
				min = numeros[i];
			}
			if(numeros[i] > max) {
				max = numeros[i];
			}
		}
		prom = total/cant;
	}
	
	public void punto_3() {
		Archivo archivo_out = new Archivo("aleatorio.out");
		archivo_out.guardarArchivo(this.toString());
	}
	
	@Override
	public String toString() {
		String str = cuadrito("Maximo  ", max);
		str += cuadrito("Minimo  ", min);
		str += cuadrito("Promedio", prom);
		str += String.format("+----------+-------+");
		return str;
	}

	private String cuadrito(String str, int num) {
		return String.format(
				"+----------+-------+\n" + 
				"| %s | %5d |\n",
				str, num);
	}
}
