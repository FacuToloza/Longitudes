package ej;

public enum UnidadesDeMedida {
	METRO, KILOMETRO, PIE, MILLA;
}
