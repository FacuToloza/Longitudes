package ej;
import static ej.UnidadesDeMedida.*;

public class Conversor {
	private String medida;
	private double valor;
	
	public Conversor(UnidadesDeMedida unidad, double _valor) {
		valor = a_metros(_valor, unidad);
	}
	
	private double a_metros(double _valor, UnidadesDeMedida unidad) {
		switch (unidad) {
		case KILOMETRO:
			_valor *= 1000;
			break;

		case PIE:
			_valor /= 3.28084;
			break;
			
		case MILLA:
			_valor *= 1609.34;
			break;
			
		case METRO: 
			medida = "m";
			break;
		}
		
		return _valor;
	}
	
	public Conversor convertir(UnidadesDeMedida unidad) {
		Conversor aux = new Conversor(METRO, valor);;
				
		if (unidad == KILOMETRO) {
			aux.valor /= 1000.0;
			aux.medida = "km";
		} else if (unidad == PIE) {
			aux.valor *= 3.28084;
			aux.medida = "pie";
		} else if (unidad == MILLA) {
			aux.valor /= 1609.34;
			aux.medida = "milla";
		}
		return aux;
	}
	
	@Override
	public String toString() {
		return valor + " " + medida;
	}

	public static void main(String[] args) {
		Conversor c_1 = new Conversor(METRO, 128.0);
		System.out.println("En metros: " + c_1.convertir(METRO));
		System.out.println("En kilometros: " + c_1.convertir(KILOMETRO));
		System.out.println("En millas: " + c_1.convertir(MILLA));
		System.out.println("En pie: " + c_1.convertir(PIE));
	}
}
