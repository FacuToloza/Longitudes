
import java.io.*;
import java.util.Locale;
import java.util.Scanner;

public class Archivo {
	private String nombre;

	// Constructor
	public Archivo(String nombre) {
		this.nombre = nombre;
	}
	
	public int[] leerArchivo() {
		Scanner scanner = null;
		int[] datos = null;

		try {
			File file = new File(this.nombre);
			scanner = new Scanner(file);
			// Especifica la configuraci�n regional que se va a utilizar
			scanner.useLocale(Locale.ENGLISH);
			// Para la configuraci�n regional de Argentina, utilizar:
			// arch.useLocale(new Locale("es_AR"));

			int cant = scanner.nextInt();
			datos = new int[cant];
			for (int i = 0; i < cant; i++) {
				int n = scanner.nextInt();
				datos[i] = n;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Cerrar el archivo, eso es mucho muy importante
			scanner.close();
		}
		return datos;
	}
	
	public void guardarArchivo(int[] datos) {
		FileWriter file = null;
		PrintWriter printerWriter = null;

		try {
			file = new FileWriter(this.nombre);
			printerWriter = new PrintWriter(file);

			printerWriter.println(datos.length);
			for (int i = 0; i < datos.length; i++) {
				printerWriter.println(datos[i]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void guardarArchivo(String datos) {
		FileWriter file = null;
		PrintWriter printerWriter = null;

		try {
			file = new FileWriter(this.nombre);
			printerWriter = new PrintWriter(file);
			printerWriter.println(datos);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (file != null) {
				try {
					file.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
