package unidades;

public class Kilometro extends UnidadesDeLongitud {
		
	public Kilometro(double valor) {
		super(valor);
	}
	
	
	
	
	@Override
	public String toString() {
		return super.toString() + "km";
	}
	
	@Override
	public Metro toMetro() {
		return new Metro(getValor() * 1000);
	}
	
	@Override
	public Milla toMilla() {
		return new Milla(getValor() * 0.621371);
	}
	
	@Override
	public Pie toPie() {
		return new Pie(getValor() * 3280.84);
	}

	@Override
	public Kilometro toKilometro() {
		return new Kilometro(getValor());
	}

	@Override
	public Kilometro add(UnidadesDeLongitud p) {
		Kilometro aux = new Kilometro(getValor());
		aux.setValor(getValor() + p.toKilometro().getValor());
		return aux;
	}
}
