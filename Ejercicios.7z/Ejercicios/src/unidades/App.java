package unidades;

public class App {
	public static void main(String[] args) {
		Pie pi = new Pie(100);
		Metro me = new Metro(100);
		Milla mi = new Milla(100);
		Kilometro km = new Kilometro(100);
		
		UnidadesDeLongitud[] medidas = {me,km,pi,mi};
		Metro total = new Metro(0);
		for (UnidadesDeLongitud medida : medidas) {
			System.out.println(medida.toMetro());
			total = total.add(medida);
		}
		System.out.println("Total: " + total);
		
		System.out.println("\nSumas:\n" + me.add(km));
		System.out.println(pi.add(me));
		System.out.println(me.toPie());
	}
}
