package unidades;

import static org.junit.Assert.*;

import org.junit.Test;

public class UnidadesTest {

	@SuppressWarnings("deprecation")
	@Test
	public void test() {
		Kilometro km = new Kilometro(200.00);
		
		//assertNotNull(km);
		assertEquals(200.00, km.getValor());
	}

}
