package unidades;

public class Pie extends UnidadesDeLongitud {
		
	public Pie(double valor) {
		super(valor);
	}
	
	@Override
	public String toString() {
		return super.toString() + " Pie";
	}
	
	@Override
	public Kilometro toKilometro() {
		return new Kilometro(getValor() / 3280.84);
	}
	
	@Override
	public Milla toMilla() {
		return new Milla(getValor() / 5280);
	}
	
	@Override
	public Metro toMetro() {
		return new Metro(getValor() / 3.28084);
	}

	@Override
	public Pie toPie() {
		return new Pie(getValor());
	}

	@Override
	public Pie add(UnidadesDeLongitud p) {
		Pie aux = new Pie(getValor());
		aux.setValor(getValor() + p.toPie().getValor());
		return aux;
	}
}
