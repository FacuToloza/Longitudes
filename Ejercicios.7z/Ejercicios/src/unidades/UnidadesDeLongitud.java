package unidades;

public abstract class UnidadesDeLongitud {
	private double valor;
	
	public UnidadesDeLongitud(double valor) {
		super();
		setValor(valor);
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	@Override
	public String toString() {
		return "" + valor;
	}
	
	public abstract Kilometro toKilometro();
	public abstract Milla toMilla();
	public abstract Pie toPie();
	public abstract Metro toMetro();
	public abstract UnidadesDeLongitud add(UnidadesDeLongitud p);
}
