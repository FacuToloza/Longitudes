package unidades;

public class Milla extends UnidadesDeLongitud {
	
	public Milla(double valor) {
		super(valor);
	}
	
	@Override
	public String toString() {
		return super.toString() + " Milla";
	}
	
	@Override
	public Kilometro toKilometro() {
		return new Kilometro(getValor() / 0.621371);
	}
	
	@Override
	public Metro toMetro() {
		return new Metro(getValor() * 1609.34);
	}
	
	@Override
	public Pie toPie() {
		return new Pie(getValor() * 5280);
	}

	@Override
	public Milla toMilla() {
		return new Milla(getValor());
	}

	@Override
	public Milla add(UnidadesDeLongitud p) {
		Milla aux = new Milla(getValor());
		aux.setValor(getValor() + p.toMilla().getValor());
		return aux;
	}


}
