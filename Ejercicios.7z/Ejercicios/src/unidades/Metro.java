package unidades;

public class Metro extends UnidadesDeLongitud {

	public Metro(double valor) {
		super(valor);
	}
	
	@Override
	public String toString() {
		return super.toString() + "m";
	}
	
	@Override
	public Kilometro toKilometro() {
		return new Kilometro(getValor() / 1000);
	}
	
	@Override
	public Milla toMilla() {
		return new Milla(getValor() / 1609.34);
	}
	
	@Override
	public Pie toPie() {
		return new Pie(getValor() * 3.28084);
	}

	@Override
	public Metro toMetro() {
		return new Metro(getValor());
	}

	@Override
	public Metro add(UnidadesDeLongitud p) {
		Metro aux = new Metro(getValor());
		aux.setValor(getValor() + p.toMetro().getValor());
		return aux;
	}
}
