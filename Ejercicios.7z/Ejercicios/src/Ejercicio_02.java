import java.util.Arrays;

/* Escribir un m�todo en Java que de una matriz num�rica dada, 
 * devuelva una matriz con la misma cantidad de elementos,
 *  pero donde cada valor es la suma de sus adyacentes originales 
 *  (arriba, abajo, izquierda, y derecha; si existen) */

public class Ejercicio_02 {
	public int[][] resolucion(final int[][] matriz) {
		int fila_tamanio = matriz.length;
		int columna_tamanio = matriz[0].length;
		
		int[][] nueva_matriz = new int[fila_tamanio][columna_tamanio];
		
		for(int i = 0; i < fila_tamanio; i++) {
			for(int j = 0; j < columna_tamanio; j++) {
				nueva_matriz[i][j] = matriz[i][j];
				
				//Derecha
				if(j < columna_tamanio - 1) {
					nueva_matriz[i][j] += matriz[i][j+1];
				}
				//Izquierda
				if(j > 0) {
					nueva_matriz[i][j] += matriz[i][j-1];
				}
				
				//Abajo
				if(i < fila_tamanio - 1) {
					nueva_matriz[i][j] += matriz[i+1][j];
				}
				//Arriba
				if(i > 0) {
					nueva_matriz[i][j] += matriz[i-1][j];
				}
			}
		}
		
		return nueva_matriz;
	}
	
	public static void main(String[] args) {
		int[][] prueba = {
				{8,2,-3,4},
				{5,-6,-6,20},
				{21,1,-5,0}
		};
		
		int[][] resultado = {
				{15,1,-3,21},
				{28,-4,0,18},
				{27,11,-10,15}
		};
		
		boolean bien = true;
		
		Ejercicio_02 mi_ejercicio = new Ejercicio_02();
		int [][] salida = mi_ejercicio.resolucion(prueba);
		
		for(int i = 0; i < salida.length; i++) {
			System.out.println(Arrays.toString(salida[i]));
		}
		
		for(int i = 0; i < salida.length; i++) {
			for(int j = 0; j < salida[0].length; j++) {
				if(salida[i][j] != resultado[i][j]) {
					bien = false;
				}
			}
		}
		
		if(bien) {
			System.out.println("Ejercicio resuelto correctamente");
		}
		else {
			System.out.println("NO");
		}
	}
}
